from .analytics import SalesAnalytics

__all__ = ["SalesAnalytics"]
